/* Gianna Screen*/

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {
    
    // Test for valid task creation
    @Test
    public void valid_CreateTask() {
        Task task = new Task("TASK001", "Update Record", "Update record with new surnames");
        
        assertNotNull(task);
        assertNotNull(task.retrieveTaskId());
        assertNotNull(task.retrieveName());
        assertNotNull(task.retrieveDescription());
    }
    
    // Test for null task ID
    @Test
    public void invalidTaskId_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Update Record v1", "Update record with new surnames");
        });
    }
    
    // Test for task ID too long
    @Test
    public void invalidTaskId_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TASK0024567891011", "Update Record v2", "Update record with new surnames");
        });
    }
    
    // Test for null name
    @Test
    public void invalidName_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TASK003", null, "Update record with new surnames");
        });
    }
    
    // Test for name too long
    @Test
    public void invalidName_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TASK004", "Update Record With Extra Long Name", "Update record with new surnames");
        });
    }
    
    // Test for null description
    @Test
    public void invalidDescription_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TASK005", "Update Record v5", null);
        });
    }
    
    // Test for description too long
    @Test
    public void invalidDescription_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("TASK006", "Update Record v6", 
                "Update record with new surnames and additional unnecessary details that exceed the maximum allowed length of 50 characters");
        });
    }
    
    // Test for valid name update
    @Test
    public void valid_SetName() {
        Task task = new Task("TASK007", "Update Record v7", "Update record with new surnames");
        task.setName("Update Entry");
        assertEquals("Update Entry", task.retrieveName());
    }
    
    // Test for valid description update
    @Test
    public void valid_SetDescription() {
        Task task = new Task("TASK008", "Update Record v8", "Update record with new surnames");
        task.setDescription("Update record with new contact details");
        assertEquals("Update record with new contact details", task.retrieveDescription());
    }
}