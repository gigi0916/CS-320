/* Gianna Screen*/ 

import java.util.List;
import java.util.ArrayList;

// Task service class
public class TaskService {
    private List<Task> tasks; 
    
    public TaskService() {
        tasks = new ArrayList<>();
    }
    
    // Add new task
    public void createTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Invalid - Task is Null");
        }
        
        try {
            getTask(task.retrieveTaskId());
            throw new IllegalArgumentException("Invalid - Task ID already exists");
        } catch (IllegalArgumentException e) {
            if (e.getMessage().contains("Invalid - Task not found")) {
                tasks.add(task);
            } else {
                throw e;
            }
        }
    }
    
    // Remove task by taskID
    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Invalid - Task is Null");
        }
        
        for (Task task : tasks) {
            if (task.retrieveTaskId().equals(taskId)) {
                tasks.remove(task);
                return;
            }
        }
        
        throw new IllegalArgumentException("Invalid - Task not found");
    }
    
    // Update task name
    public void updateName(String taskId, String name) {
        Task task = getTask(taskId);
        task.setName(name);
    }
    
    // Update task description
    public void updateDescription(String taskId, String description) {
        Task task = getTask(taskId);
        task.setDescription(description);
    }
    
    // retrieve task by ID
    public Task getTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Invalid - Task is Null");
        }
        
        for (Task task : tasks) {
            if (task.retrieveTaskId().equals(taskId)) {
                return task;
            }
        }
        
        throw new IllegalArgumentException("Invalid - Task not found");
    }
}