/* Gianna Screen*/ 

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    // Test for valid task creation
    @Test
    public void valid_CreateTask() {
        Task task = new Task("TASK001", "Update Record", "Update record with new surnames");
        
        assertNotNull(task);
        assertNotNull(task.retrieveTaskId());
        assertNotNull(task.retrieveName());
        assertNotNull(task.retrieveDescription());
    }

    // Test for null task addition
    @Test
    public void invalidAddTask_Null() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.createTask(null);
        });
    }

    // Test for valid task deletion
    @Test
    public void valid_DeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("TASK002", "Update Record v2", "Update record with new contact information");
        service.createTask(task);

        service.deleteTask("TASK002");
        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("TASK002");
        });
    }

    // Test for null task deletion
    @Test
    public void invalidDeleteTask_Null() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask(null);
        });
    }

    // Test for delete task not found
    @Test
    public void invalidDeleteTask_NotFound() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("TASKNOTFOUND");
        });
    }

    // Test for valid name update
    @Test
    public void validUpdate_Name() {
        TaskService service = new TaskService();
        Task task = new Task("TASK003", "Update Record v3", "Update record with new address details");
        service.createTask(task);

        service.updateName("TASK003", "Update Entry");
        assertEquals("Update Entry", service.getTask("TASK003").retrieveName());
    }

    // Test for valid description update
    @Test
    public void valid_UpdateDescription() {
        TaskService service = new TaskService();
        Task task = new Task("TASK004", "Update Record v4", "Update record with new surnames");
        service.createTask(task);

        service.updateDescription("TASK004", "Update record with new phone numbers");
        assertEquals("Update record with new phone numbers", service.getTask("TASK004").retrieveDescription());
    }

    // Test for update task not found
    @Test
    public void invalidUpdateTask_NotFound() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("TASK999", "Update Entry");
        });
    }

    // Test for valid task retrieval
    @Test
    public void valid_RetrieveTask() {
        TaskService service = new TaskService();
        Task task = new Task("TASK005", "Update Record v5", "Update record with new email addresses");
        service.createTask(task);

        Task result = service.getTask("TASK005");
        assertNotNull(result);
        assertEquals("TASK005", result.retrieveTaskId());
    }

    // Test for null task retrieval
    @Test
    public void invalidRetrieveTask_Null() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask(null);
        });
    }

    // Test for retrieve task not found
    @Test
    public void invalidRetrieveTask_NotFound() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getTask("TASKNOTFOUND");
        });
    }
}