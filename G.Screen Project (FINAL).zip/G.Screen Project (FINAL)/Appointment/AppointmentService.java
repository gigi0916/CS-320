/* Gianna Screen*/ 

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

// Appointment service class
public class AppointmentService {
    private List<Appointment> appointments; 
    
    public AppointmentService() {
        appointments = new ArrayList<>();
    }
    
    // Add new appointment
    public void createAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Invalid - Appointment is Null");
        }
        
        try {
            getAppointment(appointment.retrieveAppointmentId());
            throw new IllegalArgumentException("Invalid - Appointment ID already exists");
        } catch (IllegalArgumentException e) {
            if (e.getMessage().contains("Invalid - Appointment not found")) {
                appointments.add(appointment);
            } else {
                throw e;
            }
        }
    }
    
    // Remove appointment by appointmentID
    public void deleteAppointment(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("Invalid - Appointment is Null");
        }
        
        for (Appointment appointment : appointments) {
            if (appointment.retrieveAppointmentId().equals(appointmentId)) {
                appointments.remove(appointment);
                return;
            }
        }
        
        throw new IllegalArgumentException("Invalid - Appointment not found");
    }
    
    // Update appointment date
    public void updateAppointmentDate(String appointmentId, Date appointmentDate) {
        Appointment appointment = getAppointment(appointmentId);
        appointment.setAppointmentDate(appointmentDate);
    }
    
    // Update appointment description
    public void updateDescription(String appointmentId, String description) {
        Appointment appointment = getAppointment(appointmentId);
        appointment.setDescription(description);
    }
    
    // retrieve appointment by ID
    public Appointment getAppointment(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("Invalid - Appointment is Null");
        }
        
        for (Appointment appointment : appointments) {
            if (appointment.retrieveAppointmentId().equals(appointmentId)) {
                return appointment;
            }
        }
        
        throw new IllegalArgumentException("Invalid - Appointment not found");
    }
}