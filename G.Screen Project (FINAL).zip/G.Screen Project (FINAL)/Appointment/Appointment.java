/* Gianna Screen*/ 

import java.util.Date;

// Appointment object class
public class Appointment {
    private final String appointmentId; 
    private Date appointmentDate; 
    private String description;
    
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointment ID
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID is invalid");
        }
        
        // Validate appointment date
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date is invalid");
        }
        
        // Validate description field
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid");
        }
        
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }
    
    // Get appointment ID
    public String retrieveAppointmentId() {
        return appointmentId;
    }
    
    // Get appointment date
    public Date retrieveAppointmentDate() {
        return appointmentDate;
    }
    
    // Get appointment description
    public String retrieveDescription() {
        return description;
    }
    
    // Set appointment date
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date is invalid");
        }
        this.appointmentDate = appointmentDate;
    }
    
    //  Set appointment description
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is invalid");
        }
        this.description = description;
    }
}