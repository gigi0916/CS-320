/* Gianna Screen*/

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {
    
    // Test for valid appointment creation
    @Test
    public void valid_CreateAppointment() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT001", apptDate, "Mandatory check-up dentist appointment");
        
        assertNotNull(appointment);
        assertNotNull(appointment.retrieveAppointmentId());
        assertNotNull(appointment.retrieveAppointmentDate());
        assertNotNull(appointment.retrieveDescription());
    }
    
    // Test for null appointment ID
    @Test
    public void invalidAppointmentId_Null() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, apptDate, "Mandatory check-up dentist appointment");
        });
    }
    
    // Test for appointment ID too long
    @Test
    public void invalidAppointmentId_TooLong() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APPT001234567891011", apptDate, "Mandatory check-up dentist appointment");
        });
    }
    
    // Test for null appointment date
    @Test
    public void invalidAppointmentDate_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APPT003", null, "Mandatory check-up dentist appointment");
        });
    }
    
    // Test for appointment date in the past
    @Test
    public void invalidAppointmentDate_Past() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, -1);
        Date pastDate = calendar.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APPT004", pastDate, "Mandatory check-up dentist appointment");
        });
    }
    
    // Test for null description
    @Test
    public void invalidDescription_Null() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APPT005", apptDate, null);
        });
    }
    
    // Test for description too long
    @Test
    public void invalidDescription_TooLong() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APPT006", apptDate, 
                "Mandatory check-up dentist appointment with additional extra details that exceed the maximum requirement length of 50 characters");
        });
    }
    
    // Test for valid appointment date update
    @Test
    public void valid_SetAppointmentDate() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate1 = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT007", apptDate1, "Mandatory check-up dentist appointment");
        
        calendar.add(Calendar.DAY_OF_MONTH, 2);
        Date apptDate2 = calendar.getTime();
        
        appointment.setAppointmentDate(apptDate2);
        assertEquals(apptDate2, appointment.retrieveAppointmentDate());
    }
    
    // Test for valid description update
    @Test
    public void valid_SetDescription() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT008", apptDate, "Mandatory check-up dentist appointment");
        appointment.setDescription("Dental extraction appointment");
        assertEquals("Dental extraction appointment", appointment.retrieveDescription());
    }
}