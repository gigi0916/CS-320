/* Gianna Screen*/ 

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentServiceTest {

    // Test for valid appointment creation
    @Test
    public void valid_CreateAppointment() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT001", apptDate, "Mandatory check-up dentist appointment");
        
        assertNotNull(appointment);
        assertNotNull(appointment.retrieveAppointmentId());
        assertNotNull(appointment.retrieveAppointmentDate());
        assertNotNull(appointment.retrieveDescription());
    }

    // Test for null appointment addition
    @Test
    public void invalidAddAppointment_Null() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.createAppointment(null);
        });
    }

    // Test for valid appointment deletion
    @Test
    public void valid_DeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT002", apptDate, "Dental extraction appointment");
        service.createAppointment(appointment);

        service.deleteAppointment("APPT002");
        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("APPT002");
        });
    }

    // Test for null appointment deletion
    @Test
    public void invalidDeleteAppointment_Null() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment(null);
        });
    }

    // Test for delete appointment not found
    @Test
    public void invalidDeleteAppointment_NotFound() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("Appointment not found");
        });
    }

    // Test for valid appointment retrieval
    @Test
    public void valid_RetrieveAppointment() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT005", apptDate, "Dental exam appointment");
        service.createAppointment(appointment);

        Appointment result = service.getAppointment("APPT005");
        assertNotNull(result);
        assertEquals("APPT005", result.retrieveAppointmentId());
    }

    // Test for null appointment retrieval
    @Test
    public void invalidRetrieveAppointment_Null() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment(null);
        });
    }

    // Test for retrieve appointment not found
    @Test
    public void invalidRetrieveAppointment_NotFound() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("Appointment not found");
        });
    }
    
    // Test for duplicate appointment ID
    @Test
    public void invalidAddAppointment_DuplicateId() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment1 = new Appointment("APPT006", apptDate, "appointment #1");
        service.createAppointment(appointment1);
        
        Appointment appointment2 = new Appointment("APPT006", apptDate, "appointment #2");
        assertThrows(IllegalArgumentException.class, () -> {
            service.createAppointment(appointment2);
        });
    }
    
    // Test for valid appointment date update
    @Test
    public void valid_UpdateAppointmentDate() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate1 = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT007", apptDate1, "Dental cleaning appointment");
        service.createAppointment(appointment);
        
        calendar.add(Calendar.DAY_OF_MONTH, 2);
        Date apptDate2 = calendar.getTime();
        
        service.updateAppointmentDate("APPT007", apptDate2);
        assertEquals(apptDate2, service.getAppointment("APPT007").retrieveAppointmentDate());
    }
    
    // Test for valid description update
    @Test
    public void valid_UpdateDescription() {
        AppointmentService service = new AppointmentService();
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        Date apptDate = calendar.getTime();
        
        Appointment appointment = new Appointment("APPT008", apptDate, "Dental cleaning appointment");
        service.createAppointment(appointment);
        
        service.updateDescription("APPT008", "Dental extraction appointment");
        assertEquals("Dental extraction appointment", service.getAppointment("APPT008").retrieveDescription());
    }
    
    // Test for update appointment not found
    @Test
    public void invalidUpdateAppointment_NotFound() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("Appoinment not found", "New description");
        });
    }
}