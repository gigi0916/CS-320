/* Gianna Screen*/ 

import java.util.List;
import java.util.ArrayList;

// Contact service class
public class ContactService {
    private List<Contact> contacts;
    
    public ContactService() {
        contacts = new ArrayList<>();
    }
    
    // Add new contact
    public void createContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Invalid - Contact is Null");
        }
        
        try {
            getContact(contact.retrieveContactId());
            throw new IllegalArgumentException("Invalid - Contact ID already exists");
        } catch (IllegalArgumentException e) {
            if (e.getMessage().contains("Invalid - Contact not found")) {
                contacts.add(contact);
            } else {
                throw e;
            }
        }
    }
    
    // Remove contact by contactId
    public void deleteContact(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("Invalid - Contact is Null");
        }
        
        for (Contact contact : contacts) {
            if (contact.retrieveContactId().equals(contactId)) {
                contacts.remove(contact);
                return;
            }
        }
        
        throw new IllegalArgumentException("Invalid - Contact not found");
    }
    
    // Update contact first name
    public void updateFirstName(String contactId, String firstName) {
        Contact contact = getContact(contactId);
        contact.setFirstName(firstName);
    }
    
    // Update contact last name
    public void updateLastName(String contactId, String lastName) {
        Contact contact = getContact(contactId);
        contact.setLastName(lastName);
    }
    
    // Update contact phone number
    public void updatePhone(String contactId, String phone) {
        Contact contact = getContact(contactId);
        contact.setPhone(phone);
    }
    
    // Update contact address
    public void updateAddress(String contactId, String address) {
        Contact contact = getContact(contactId);
        contact.setAddress(address);
    }
    
    // Retrieve contact by ID
    public Contact getContact(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("Invalid - Contact is Null");
        }
        
        for (Contact contact : contacts) {
            if (contact.retrieveContactId().equals(contactId)) {
                return contact;
            }
        }
        
        throw new IllegalArgumentException("Invalid - Contact not found");
    }
}