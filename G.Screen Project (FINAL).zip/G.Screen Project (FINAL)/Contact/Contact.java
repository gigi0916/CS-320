/* Gianna Screen*/ 

// Contact object class
public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;
    
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        // Validate contact ID
        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Contact ID is invalid");
        }
        
        // Validate first name
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First Name is invalid");
        }
        
        // Validate last name
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name is Invalid");
        }
        
        // Validate phone number
        if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number is Invalid");
        }
        
        // Validate address
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address is Invalid");
        }
        
        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }
    
    // Get contact ID
    public String retrieveContactId() {
        return contactId;
    }
    
    // Get first name
    public String retrieveFirstName() {
        return firstName;
    }
    
    // Get last name
    public String retrieveLastName() {
        return lastName;
    }
    
    // Get phone number
    public String retrievePhone() {
        return phone;
    }
    
    // Get address
    public String retrieveAddress() {
        return address;
    }
    
    // Set first name
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("First name is Invalid");
        }
        this.firstName = firstName;
    }
    
    // Set last name
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Last name is Invalid");
        }
        this.lastName = lastName;
    }
    
    // Set phone number
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10 || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number is Invalid");
        }
        this.phone = phone;
    }
    
    // Set address
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Address is Invalid");
        }
        this.address = address;
    }
}