/* Gianna Screen*/ 

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {
    
    // Test for valid contact creation
    @Test
    public void valid_CreateContact() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        
        assertNotNull(contact);
        assertNotNull(contact.retrieveContactId());
        assertNotNull(contact.retrieveFirstName());
        assertNotNull(contact.retrieveLastName());
        assertNotNull(contact.retrievePhone());
        assertNotNull(contact.retrieveAddress());
    }
    
    // Test for null contact ID
    @Test
    public void invalidContactId_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Peter", "Parker", "7185429876", "2 Berry St");
        });
    }
    
    // Test for contact ID too long
    @Test
    public void invalidContactId_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("SPIDERMAN001", "Peter", "Parker", "7185429876", "3 Cherry Ave");
        });
    }
    
    // Test for null first name
    @Test
    public void invalidFirstName_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("BANNER01", null, "Banner", "3125847392", "4 Maple Dr");
        });
    }
    
    // Test for first name too long
    @Test
    public void invalidFirstName_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("BANNER01", "BruceBanner", "Banner", "3125847392", "5 Oak Ln");
        });
    }
    
    // Test for null last name
    @Test
    public void invalidLastName_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("WIDOW007", "Natasha", null, "2023967451", "6 Pine Way");
        });
    }
    
    // Test for null phone number
    @Test
    public void invalidPhone_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ROGERS01", "Steve", "Rogers", null, "8 Birch Rd");
        });
    }
    
    // Test for phone number too short
    @Test
    public void invalidPhone_TooShort() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("ROGERS01", "Steve", "Rogers", "555123456", "9 Cedar Ave");
        });
    }
    
    // Test for null address
    @Test
    public void invalidAddress_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("HAWKEYE1", "Clint", "Barton", "5034729183", null);
        });
    }
    
    // Test for address too long
    @Test
    public void invalidAddress_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("HAWKEYE1", "Clint", "Barton", "5034729183", "12847 Whispering Pines Boulevard Lane");
        });
    }
    
    // Test for valid first name update
    @Test
    public void valid_SetFirstName() {
        Contact contact = new Contact("LANG001", "Scott", "Lang", "4153829475", "12 Ash St");
        contact.setFirstName("Paul");
        assertEquals("Paul", contact.retrieveFirstName());
    }
    
    // Test for valid phone number update
    @Test
    public void valid_SetPhone() {
        Contact contact = new Contact("STRANGE1", "Stephen", "Strange", "2129384756", "14 Fir Ave");
        contact.setPhone("2125847293");
        assertEquals("2125847293", contact.retrievePhone());
    }
    
    // Test for valid address update
    @Test
    public void valid_SetAddress() {
        Contact contact = new Contact("PANTHER1", "TChalla", "Udaku", "9174829375", "15 Hickory Dr");
        contact.setAddress("16 Walnut Way");
        assertEquals("16 Walnut Way", contact.retrieveAddress());
    }
    
    // Test for set first name with null value
    @Test
    public void invalidSetFirstName_Null() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }

    // Test for set first name too long
    @Test
    public void invalidSetFirstName_TooLong() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("TonyStarkIronMan");
        });
    }

    // Test for set last name with null value
    @Test
    public void invalidSetLastName_Null() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
    }

    // Test for set last name too long
    @Test
    public void invalidSetLastName_TooLong() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("StarkTooLong");
        });
    }

    // Test for set phone number with null value
    @Test
    public void invalidSetPhone_Null() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone(null);
        });
    }

    // Test for set phone number too short
    @Test
    public void invalidSetPhone_TooShort() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("123456789");
        });
    }

    // Test for set phone number not numeric
    @Test
    public void invalidSetPhone_NotNumeric() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("123456789a");
        });
    }

    // Test for set address with null value
    @Test
    public void invalidSetAddress_Null() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
    }

    // Test for set address too long
    @Test
    public void invalidSetAddress_TooLong() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("12847 Whispering Pines Boulevard Lane Extension");
        });
    }
    
}