/* Gianna Screen*/ 

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    // Test for valid contact creation
    @Test
    public void valid_CreateContact() {
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        
        assertNotNull(contact);
        assertNotNull(contact.retrieveContactId());
        assertNotNull(contact.retrieveFirstName());
        assertNotNull(contact.retrieveLastName());
        assertNotNull(contact.retrievePhone());
        assertNotNull(contact.retrieveAddress());
    }

    // Test for null contact addition
    @Test
    public void invalidAddContact_Null() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.createContact(null);
        });
    }

    // Test for valid contact deletion
    @Test
    public void valid_DeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        service.createContact(contact);

        service.deleteContact("STARK001");
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("STARK001");
        });
    }

    // Test for null contact deletion
    @Test
    public void invalidDeleteContact_Null() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact(null);
        });
    }

    // Test for delete contact not found
    @Test
    public void invalidDeleteContact_NotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("Contact not Found");
        });
    }

    // Test for valid first name update
    @Test
    public void validUpdate_FirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        service.createContact(contact);

        service.updateFirstName("STARK001", "Peter");
        assertEquals("Peter", service.getContact("STARK001").retrieveFirstName());
    }

    // Test for valid phone update
    @Test
    public void valid_UpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        service.createContact(contact);

        service.updatePhone("STARK001", "5551234567");
        assertEquals("5551234567", service.getContact("STARK001").retrievePhone());
    }

    // Test for update contact not found
    @Test
    public void invalidUpdateContact_NotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("Contact not Found", "Peter");
        });
    }

    // Test for valid contact retrieval
    @Test
    public void valid_RetrieveContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        service.createContact(contact);

        Contact result = service.getContact("STARK001");
        assertNotNull(result);
        assertEquals("STARK001", result.retrieveContactId());
    }

    // Test for null contact retrieval
    @Test
    public void invalidRetrieveContact_Null() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact(null);
        });
    }

    // Test for retrieve contact not found
    @Test
    public void invalidRetrieveContact_NotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.getContact("Contact not Found");
        });
    }
    
    // Test for valid last name update
    @Test
    public void valid_UpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        service.createContact(contact);

        service.updateLastName("STARK001", "Banner");
        assertEquals("Banner", service.getContact("STARK001").retrieveLastName());
    }

    // Test for valid address update
    @Test
    public void valid_UpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("STARK001", "Tony", "Stark", "9172847361", "1 Apple Rd");
        service.createContact(contact);

        service.updateAddress("STARK001", "2 Berry St");
        assertEquals("2 Berry St", service.getContact("STARK001").retrieveAddress());
    }

    // Test for update last name not found
    @Test
    public void invalidUpdateLastName_NotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateLastName("Last name not found", "Banner");
        });
    }

    // Test for update phone not found
    @Test
    public void invalidUpdatePhone_NotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updatePhone("Phone not found", "5551234567");
        });
    }

    // Test for update address not found
    @Test
    public void invalidUpdateAddress_NotFound() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateAddress("Address not found", "2 Berry St");
        });
    }
}